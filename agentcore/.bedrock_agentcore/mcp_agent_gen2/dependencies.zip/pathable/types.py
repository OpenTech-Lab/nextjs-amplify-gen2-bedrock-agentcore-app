"""Pathable types module"""
from typing import Union

PartType = Union[str, int]
